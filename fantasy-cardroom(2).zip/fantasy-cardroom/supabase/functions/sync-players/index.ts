import { createClient } from 'npm:@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-secret',
}

const TEAMS: Record<string, [string,string]> = {
  BUF:['AFC','AFC East'], MIA:['AFC','AFC East'], NE:['AFC','AFC East'], NYJ:['AFC','AFC East'],
  BAL:['AFC','AFC North'], CIN:['AFC','AFC North'], CLE:['AFC','AFC North'], PIT:['AFC','AFC North'],
  HOU:['AFC','AFC South'], IND:['AFC','AFC South'], JAX:['AFC','AFC South'], JAC:['AFC','AFC South'], TEN:['AFC','AFC South'],
  DEN:['AFC','AFC West'], KC:['AFC','AFC West'], LV:['AFC','AFC West'], LAC:['AFC','AFC West'],
  DAL:['NFC','NFC East'], NYG:['NFC','NFC East'], PHI:['NFC','NFC East'], WAS:['NFC','NFC East'], WSH:['NFC','NFC East'],
  CHI:['NFC','NFC North'], DET:['NFC','NFC North'], GB:['NFC','NFC North'], MIN:['NFC','NFC North'],
  ATL:['NFC','NFC South'], CAR:['NFC','NFC South'], NO:['NFC','NFC South'], TB:['NFC','NFC South'],
  ARI:['NFC','NFC West'], LAR:['NFC','NFC West'], LA:['NFC','NFC West'], SF:['NFC','NFC West'], SEA:['NFC','NFC West'],
}

function providerHeaders(key:string){ return { 'Ocp-Apim-Subscription-Key': key } }
async function getJson(url:string,key:string){
  const r=await fetch(url,{headers:providerHeaders(key)})
  if(!r.ok) throw new Error(`${r.status} from ${url}: ${await r.text()}`)
  return await r.json()
}
function flattenDepth(raw:any[]):any[]{
  const out:any[]=[]
  for(const row of raw||[]){
    if(Array.isArray(row?.Offense)) out.push(...row.Offense)
    else if(row?.PositionCategory==='OFF' || row?.DepthOrder!=null) out.push(row)
  }
  return out
}
function seasonStats(s:any={}){
  return {
    passing_yards:s.PassingYards??0, passing_tds:s.PassingTouchdowns??0, interceptions:s.PassingInterceptions??0,
    rushing_yards:s.RushingYards??0, rushing_tds:s.RushingTouchdowns??0,
    receptions:s.Receptions??0, receiving_yards:s.ReceivingYards??0, receiving_tds:s.ReceivingTouchdowns??0,
    fumbles_lost:s.FumblesLost??0,
  }
}

async function authorized(req:Request, admin:any){
  const cron=Deno.env.get('CRON_SECRET')
  if(cron && req.headers.get('x-cron-secret')===cron) return true
  const auth=req.headers.get('authorization')||''
  if(!auth.startsWith('Bearer ')) return false
  const token=auth.slice(7)
  const {data:{user}}=await admin.auth.getUser(token)
  if(!user) return false
  const {data}=await admin.from('profiles').select('is_admin').eq('id',user.id).single()
  return data?.is_admin===true
}

Deno.serve(async(req)=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors})
  try{
    const supabaseUrl=Deno.env.get('SUPABASE_URL')!
    const serviceKey=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const apiKey=Deno.env.get('SPORTSDATA_API_KEY')
    if(!apiKey) throw new Error('SPORTSDATA_API_KEY is not configured')
    const admin=createClient(supabaseUrl,serviceKey,{auth:{persistSession:false}})
    if(!(await authorized(req,admin))) return Response.json({error:'Forbidden'},{status:403,headers:cors})

    let body:any={}; try{ body=await req.json() }catch{}
    let season=Number(body.season||Deno.env.get('NFL_SEASON')||0)
    if(!season){
      const {data}=await admin.from('contests').select('season').order('season',{ascending:false}).limit(1).maybeSingle()
      season=data?.season||new Date().getFullYear()
    }

    const depthUrl=Deno.env.get('SPORTSDATA_DEPTH_URL')||'https://api.sportsdata.io/v3/nfl/scores/json/DepthCharts'
    const playersUrl=Deno.env.get('SPORTSDATA_PLAYERS_URL')||'https://api.sportsdata.io/v3/nfl/scores/json/Players'
    const seasonUrl=(Deno.env.get('SPORTSDATA_SEASON_STATS_URL')||'https://api.sportsdata.io/v3/nfl/stats/json/PlayerSeasonStats/{season}').replace('{season}',String(season))
    const headshotsUrl=Deno.env.get('SPORTSDATA_HEADSHOTS_URL')

    const [depthRaw,profilesRaw,seasonRaw,headshotsRaw]=await Promise.all([
      getJson(depthUrl,apiKey), getJson(playersUrl,apiKey), getJson(seasonUrl,apiKey), headshotsUrl?getJson(headshotsUrl,apiKey):Promise.resolve([])
    ])
    const depth=flattenDepth(depthRaw)
    const starters=new Set(depth.filter((d:any)=>Number(d.DepthOrder)===1 && (d.PositionCategory==='OFF' || !d.PositionCategory)).map((d:any)=>String(d.PlayerID)))
    const statsById=new Map((seasonRaw||[]).map((s:any)=>[String(s.PlayerID),s]))
    const headById=new Map((headshotsRaw||[]).map((h:any)=>[String(h.PlayerID),h.PreferredHostedHeadshotUrl||h.HostedHeadshotUrl||null]))

    const rows=[]
    for(const p of profilesRaw||[]){
      const pos=String(p.FantasyPosition||p.Position||'').toUpperCase()
      if(!['QB','RB','WR','TE'].includes(pos)) continue
      const team=String(p.Team||p.CurrentTeam||'').toUpperCase()
      const geo=TEAMS[team]
      if(!geo) continue
      const id=String(p.PlayerID)
      rows.push({
        provider_id:id, season, name:p.Name||`${p.FirstName||''} ${p.LastName||''}`.trim(), position:pos, team,
        conference:geo[0], division:geo[1], is_starter:starters.has(id),
        headshot_url:headById.get(id)||p.PreferredHostedHeadshotUrl||null,
        season_stats:seasonStats(statsById.get(id)), updated_at:new Date().toISOString(),
      })
    }
    for(let i=0;i<rows.length;i+=500){
      const {error}=await admin.from('players').upsert(rows.slice(i,i+500),{onConflict:'provider_id'})
      if(error) throw error
    }
    return Response.json({message:`Synced ${rows.length} fantasy players; ${rows.filter(r=>r.is_starter).length} are depth-chart starters for ${season}.`,season},{headers:{...cors,'Content-Type':'application/json'}})
  }catch(e){
    return Response.json({error:String(e?.message||e)},{status:500,headers:{...cors,'Content-Type':'application/json'}})
  }
})
