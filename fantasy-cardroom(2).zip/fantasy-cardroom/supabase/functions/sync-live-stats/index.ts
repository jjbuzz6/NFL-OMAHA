import { createClient } from 'npm:@supabase/supabase-js@2'

const cors={
  'Access-Control-Allow-Origin':'*',
  'Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type, x-cron-secret',
}
function providerHeaders(key:string){return{'Ocp-Apim-Subscription-Key':key}}
async function getJson(url:string,key:string){const r=await fetch(url,{headers:providerHeaders(key)});if(!r.ok)throw new Error(`${r.status} from ${url}: ${await r.text()}`);return r.json()}
function n(v:any){const x=Number(v);return Number.isFinite(x)?x:0}
function halfPpr(s:any){
  return n(s.PassingYards)/25 + n(s.PassingTouchdowns)*4 - n(s.PassingInterceptions)*2
    + n(s.RushingYards)/10 + n(s.RushingTouchdowns)*6
    + n(s.Receptions)*0.5 + n(s.ReceivingYards)/10 + n(s.ReceivingTouchdowns)*6
    + (n(s.TwoPointConversionPasses)+n(s.TwoPointConversionRuns)+n(s.TwoPointConversionReceptions))*2
    - n(s.FumblesLost)*2
}
function normalized(s:any){return{
  passing_yards:n(s.PassingYards),passing_tds:n(s.PassingTouchdowns),interceptions:n(s.PassingInterceptions),
  rushing_yards:n(s.RushingYards),rushing_tds:n(s.RushingTouchdowns),receptions:n(s.Receptions),
  receiving_yards:n(s.ReceivingYards),receiving_tds:n(s.ReceivingTouchdowns),fumbles_lost:n(s.FumblesLost),
  two_point_passes:n(s.TwoPointConversionPasses),two_point_runs:n(s.TwoPointConversionRuns),two_point_receptions:n(s.TwoPointConversionReceptions)
}}
async function authorized(req:Request,admin:any){
  const cron=Deno.env.get('CRON_SECRET');if(cron&&req.headers.get('x-cron-secret')===cron)return true
  const auth=req.headers.get('authorization')||'';if(!auth.startsWith('Bearer '))return false
  const {data:{user}}=await admin.auth.getUser(auth.slice(7));if(!user)return false
  const {data}=await admin.from('profiles').select('is_admin').eq('id',user.id).single();return data?.is_admin===true
}

Deno.serve(async(req)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors})
  try{
    const url=Deno.env.get('SUPABASE_URL')!,service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,key=Deno.env.get('SPORTSDATA_API_KEY')
    if(!key)throw new Error('SPORTSDATA_API_KEY is not configured')
    const admin=createClient(url,service,{auth:{persistSession:false}})
    if(!(await authorized(req,admin)))return Response.json({error:'Forbidden'},{status:403,headers:cors})

    let body:any={};try{body=await req.json()}catch{}
    let targets:{season:number,week:number}[]=[]
    if(body.season&&body.week) targets=[{season:Number(body.season),week:Number(body.week)}]
    else{
      const {data,error}=await admin.from('contests').select('season,week').eq('status','live')
      if(error)throw error
      const seen=new Set<string>()
      for(const c of data||[]){const k=`${c.season}-${c.week}`;if(!seen.has(k)){seen.add(k);targets.push({season:c.season,week:c.week})}}
    }
    if(!targets.length)return Response.json({message:'No live contests; scoring sync skipped.'},{headers:{...cors,'Content-Type':'application/json'}})

    const template=Deno.env.get('SPORTSDATA_WEEK_STATS_URL')||'https://api.sportsdata.io/v3/nfl/stats/json/PlayerGameStatsByWeek/{season}/{week}'
    const {data:players,error:pe}=await admin.from('players').select('id,provider_id');if(pe)throw pe
    const ids=new Map((players||[]).map((p:any)=>[String(p.provider_id),p.id]))
    let total=0
    for(const t of targets){
      const endpoint=template.replace('{season}',String(t.season)).replace('{week}',String(t.week))
      const raw=await getJson(endpoint,key)
      const rows=[]
      for(const s of raw||[]){
        const pid=ids.get(String(s.PlayerID));if(!pid)continue
        rows.push({player_id:pid,season:t.season,week:t.week,fantasy_points:Math.round(halfPpr(s)*100)/100,stats:normalized(s),game_status:s.GameStatus||s.Status||(s.IsGameOver?'Final':null),updated_at:new Date().toISOString()})
      }
      for(let i=0;i<rows.length;i+=500){const {error}=await admin.from('player_week_stats').upsert(rows.slice(i,i+500),{onConflict:'player_id,season,week'});if(error)throw error}
      total+=rows.length
    }
    return Response.json({message:`Updated ${total} player-week scores using half-PPR scoring.`,targets},{headers:{...cors,'Content-Type':'application/json'}})
  }catch(e){return Response.json({error:String(e?.message||e)},{status:500,headers:{...cors,'Content-Type':'application/json'}})}
})
